# Rev B Electrical Net Summary

## Power
USB-C VBUS -> F1 3A resettable fuse -> +5V_SYS. +5V_SYS supplies J2 LED +5V, U3 AHCT buffer VCC, and U2 AP2112 input. U2 generates +3V3 for ESP32-S3 and Qwiic. Grounds are common.

## USB
CC1 and CC2 each use 5.1k Rd to ground. D-/D+ route through U4 USBLC6-2SC6 ESD protection and 22R series resistors to GPIO19/GPIO20.

## LED data
GPIO5 -> U3 SN74AHCT1G125 input. U3 is powered at 5V and /OE is tied low. U3 output -> R7 330R -> J2 DATA. C7 1000uF is placed on the LED 5V rail near J2.

## Boot / reset
EN is pulled up to 3V3 and switched to GND for RESET. GPIO0 is pulled up to 3V3 and switched to GND for BOOT.
