# Rev B Manufacturing Notes

Recommended prototype stack: 2-layer FR-4, 1.6 mm, 1 oz copper, ENIG or lead-free HASL, green solder mask, white silkscreen. Minimum board-house capability assumed: 0.15 mm trace/space and 0.3 mm finished via drill if vias are added in a future EDA reroute.

The USB connector is GCT USB4105-GF-A-120. GCT specifies 5 A collective VBUS current capability for the connector itself; the board is intentionally protected by a 3 A resettable fuse and firmware brightness limiting is still recommended.

Use the PCB assembler's CAM/DFM preview to verify connector and module orientation. Keep copper and components clear of the ESP32-S3-WROOM-1 PCB antenna area and avoid placing the enclosure magnet directly over the antenna.
