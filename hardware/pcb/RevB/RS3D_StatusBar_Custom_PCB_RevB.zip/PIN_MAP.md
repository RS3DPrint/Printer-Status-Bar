# Rev B Firmware / Pin Map

- WS2812 LED data: ESP32-S3 GPIO5 (module pin 5) -> U3 input -> R7 330R -> J2 DATA
- Native USB D-: GPIO19 (module pin 13)
- Native USB D+: GPIO20 (module pin 14)
- I2C SDA: GPIO8 (module pin 12)
- I2C SCL: GPIO9 (module pin 17)
- Status LED: GPIO48 (module pin 25)
- BOOT: GPIO0 (module pin 27)
- RESET: EN (module pin 3)

J2 LED connector: Pin 1 = +5V, Pin 2 = DATA, Pin 3 = GND.
